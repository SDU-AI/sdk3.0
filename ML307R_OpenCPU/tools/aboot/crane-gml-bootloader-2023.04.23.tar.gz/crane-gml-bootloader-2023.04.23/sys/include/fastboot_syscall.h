#ifndef FASTBOOT_SYSCAlL_H_
#define FASTBOOT_SYSCAlL_H_

void fastboot_syscall_register(void);

#endif /* FASTBOOT_SYSCAlL_H_ */
