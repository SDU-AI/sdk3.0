#ifndef ABOOT_SYSCAlL_H_
#define ABOOT_SYSCAlL_H_

void aboot_syscall_register(void);

#endif /* ABOOT_SYSCAlL_H_ */
