#ifndef FASTBOOT_AROM_PATCH_H
#define FASTBOOT_AROM_PATCH_H

void fastboot_arom_patch(void);

#endif /* FASTBOOT_AROM_PATCH_H */
/** @} */
