#ifndef SECUREBOOT_SYSCAlL_H_
#define SECUREBOOT_SYSCAlL_H_

void secureboot_syscall_register(void);

#endif /* SECUREBOOT_SYSCAlL_H_ */
