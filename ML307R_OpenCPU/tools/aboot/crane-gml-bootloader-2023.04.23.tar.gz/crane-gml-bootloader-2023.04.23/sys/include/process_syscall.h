#ifndef PROCESS_SYSCAlL_H_
#define PROCESS_SYSCAlL_H_

void process_syscall_register(void);

#endif /* PROCESS_SYSCAlL_H_ */
