#ifndef QSPI_SYSCAlL_H_
#define QSPI_SYSCAlL_H_

void qspi_syscall_register(void);

#endif /* QSPI_SYSCAlL_H_ */
