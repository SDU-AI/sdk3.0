#ifndef LZMA_SYSCALL_H_
#define LZMA_SYSCALL_H_

void lzma_syscall_register(void);

#endif /* LZMA_SYSCALL_H_ */
