#ifndef _LOADTABLE_H_
#define _LOADTABLE_H_

#include <stdint.h>

int process_loadtable(void);

#endif
