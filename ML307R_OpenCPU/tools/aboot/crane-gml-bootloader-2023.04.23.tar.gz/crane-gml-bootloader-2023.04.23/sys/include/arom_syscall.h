#ifndef AROM_SYSCAlL_H_
#define AROM_SYSCAlL_H_

void arom_syscall_register(void);

#endif /* AROM_SYSCAlL_H_ */
