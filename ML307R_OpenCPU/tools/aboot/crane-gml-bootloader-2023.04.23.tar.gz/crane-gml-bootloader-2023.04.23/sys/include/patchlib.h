#ifndef PATCHLIB_H
#define PATCHLIB_H

#ifdef __cplusplus
extern "C" {
#endif

unsigned bl_encode(unsigned pc, unsigned target);

#ifdef __cplusplus
}
#endif

#endif /* PATCHLIB_H */
