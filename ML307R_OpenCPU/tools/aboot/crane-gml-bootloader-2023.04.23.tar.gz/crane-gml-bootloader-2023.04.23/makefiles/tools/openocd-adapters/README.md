This directory contains definitions of debugger hardware interfaces to be used
by the OpenOCD integration.
