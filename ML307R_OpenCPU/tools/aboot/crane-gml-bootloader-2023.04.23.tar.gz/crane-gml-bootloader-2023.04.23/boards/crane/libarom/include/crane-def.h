/*
 * Copyright (c) 2020, ASR microelectronics
 * All rights reserved.
 */

#ifndef CRANE_DEF_H_
#define CRANE_DEF_H_

#define SPI_CONF_CONTROLLER_COUNT 3
#define SPI_DMA_ENABLE  1

#endif /*CRANE_DEF_H_*/
