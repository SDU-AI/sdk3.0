#ifndef _SYSCALL_AROM_H_
#define _SYSCALL_AROM_H_

/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
typedef enum {
  SYSCALL_00_REGISTER                         = 0,  /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_01_UNREGISTER                       = 1,  /*   Y      Y      Y      Y      Y      Y   */
  /* mutex */
  SYSCALL_02_MUTEX_TRY_LOCK                   = 2,  /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_03_MUTEX_UNLOCK                     = 3,  /*   Y      Y      Y      Y      Y      Y   */
  /* clock */
  SYSCALL_04_CLOCK_TIME                       = 4,  /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_05_CLOCK_WAIT                       = 5,  /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_06_CLOCK_WAIT_MS                    = 6,  /*   Y      Y      Y      Y      Y      Y   */
  /* cpu */
  SYSCALL_07_HW_PLATFORM_TYPE                 = 7,  /*   Y      Y      Y      Y      Y      Y   */
  /* interrupts */
  SYSCALL_08_UNMASK_INT                       = 8,  /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_09_REGISTER_INT                     = 9,  /*   Y      Y      Y      Y      Y      Y   */
  /* dma */
  SYSCALL_10_DMAC_MAP_DEVICE_TO_CHANNEL       = 10, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_11_DMA_XFER                         = 11, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_12_DMA_CHANNEL_RUNNING              = 12, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_13_DMA_MAP_ADDR                     = 13, /*   Y      Y      N      Y      Y      Y   */
  /* gpio */
  SYSCALL_14_GPIO_INIT                        = 14, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_15_GPIO_READ                        = 15, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_16_GPIO_SET                         = 16, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_17_GPIO_CLEAR                       = 17, /*   Y      Y      N      Y      Y      Y   */
  /* qspi */
  SYSCALL_18_QSPI_INIT                        = 18, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_19_QSPI_REGISTER_CONFIG             = 19, /*   Y      Y      N      Y      Y      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  SYSCALL_20_QSPI_LUT_CONFIG                  = 20, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_21_QSPI_CMD                         = 21, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_22_QSPI_READ                        = 22, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_23_QSPI_WRITE                       = 23, /*   Y      Y      N      Y      Y      Y   */
  SYSCALL_24_QSPI_WRITE_DMA                   = 24, /*   Y      Y      N      Y      Y      Y   */
  /* secureboot */
  SYSCALL_25_SB_FIP_IMAGE_SETUP               = 25, /*   Y      N      Y      Y      Y      Y   */
  SYSCALL_26_SB_VOLUME_READ                   = 26, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_27_SB_AUTH_IMAGE                    = 27, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_28_SB_FLASH_READ                    = 28, /*   Y      Y      N      Y      Y      Y   */
  /* heapmem */
  SYSCALL_29_HEAPMEM_ALLOC                    = 29, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_30_HEAPMEM_REALLOC                  = 30, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_31_HEAPMEM_FREE                     = 31, /*   Y      Y      Y      Y      Y      Y   */
  /* process */
  SYSCALL_32_PROCESS_START                    = 32, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_33_PROCESS_EXIT                     = 33, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_34_PROCESS_POST                     = 34, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_35_PROCESS_GET_CURRENT              = 35, /*   Y      Y      Y      Y      Y      Y   */
  /* smux */
  SYSCALL_36_SMUX_USE_DEVICE                  = 36, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_37_SMUX_GET_DEVICE                  = 37, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_38_SMUX_WRITE_STDOUT                = 38, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_39_SMUX_RUNNING_MODE_SET            = 39, /*   Y      Y      Y      Y      Y      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  SYSCALL_40_SMUX_RUNNING_MODE_GET            = 40, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_41_SMUX_REGISTER_PREAMBLE_CALLBACK  = 41, /*   Y      Y      Y      Y      Y      Y   */
  /* fastboot */
  SYSCALL_42_FASTBOOT_OKAY                    = 42, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_43_FASTBOOT_FAIL                    = 43, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_44_FASTBOOT_PUBLISH                 = 44, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_45_FASTBOOT_REGISTER                = 45, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_46_FASTBOOT_UNPUBLISH_PARTITION     = 46, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_47_FASTBOOT_INFO                    = 47, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_48_FASTBOOT_PROGRESS                = 48, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_49_FASTBOOT_UPLOAD_AREA_SET         = 49, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_50_FASTBOOT_BLOCK_FREE              = 50, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_51_FASTBOOT_PROGRESS_STEP           = 51, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_52_FASTBOOT_REBOOT_SET              = 52, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_53_FASTBOOT_REBOOT_GET              = 53, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_54_FASTBOOT_FORMAT                  = 54, /*   Y      Y      Y      Y      Y      Y   */
  /* aboot cmd */
  SYSCALL_55_ABOOT_DOWNLOAD_SCRATCH_SETUP     = 55, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_56_ABOOT_REGISTER_UPLOAD_STAGE_CB   = 56, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_57_ABOOT_REGISTER_PTABLE_INFO       = 57, /*   Y      Y      Y      Y      N      N   */
  /* aboot */
  SYSCALL_58_ABOOT_REGISTER_FLASHER_PROCESS   = 58, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_59_ABOOT_REGISTER_REBOOT_CALLBACK   = 59, /*   Y      Y      Y      Y      Y      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  SYSCALL_60_ABOOT_REBOOT                     = 60, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_61_ABOOT_FLASHER_MESSAGE_DEQUEUE    = 61, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_62_ABOOT_FLASHER_MESSAGE_RELEASE    = 62, /*   Y      Y      Y      Y      Y      Y   */
  /* dbg */
  SYSCALL_63_DBG_SEND_BYTES                   = 63, /*   Y      Y      Y      Y      Y      Y   */
  /* etimer */
  SYSCALL_64_ETIMER_SET                       = 64, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_65_ETIMER_STOP                      = 65, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_66_ETIMER_RESET                     = 66, /*   Y      Y      Y      Y      Y      Y   */
  /* sys_close_all */
  SYSCALL_67_SYS_CLOSE_ALL                    = 67, /*   Y      Y      Y      Y      Y      Y   */
  /* mfp */
  SYSCALL_68_MFP_CONFIG                       = 68, /*   Y      Y      N      Y      Y      Y   */
  /* lzma */
  SYSCALL_69_LZMA_DECODE                      = 69, /*   Y      N      N      Y      Y      Y   */
  SYSCALL_70_LZMA_DECODE_MAGIC                = 70, /*   Y      N      N      Y      Y      Y   */
  /* arom */
  SYSCALL_71_AROM_MAIN_PROCESS                = 71, /*   Y      Y      Y      Y      Y      Y   */
  SYSCALL_72_AROM_PTABLE_INIT                 = 72, /*   Y      Y      N      Y      N      N   */
  /* aboot cmd */
  SYSCALL_73_ABOOT_SYS_GETVERSION             = 73, /*   N      Y      Y      Y      Y      Y   */
  /* syscall */
  SYSCALL_74_GET_SYSCALL_TABLE                = 74, /*   N      Y      Y      Y      Y      Y   */
  /* secureboot */
  SYSCALL_75_TRANSFER_CONTROL                 = 75, /*   N      Y      N      Y      Y      Y   */
  /* fastboot */
  SYSCALL_76_FASTBOOT_BOOT_SET                = 76, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_77_FASTBOOT_BOOT_GET                = 77, /*   N      Y      N      Y      Y      Y   */
  /* qspi */
  SYSCALL_78_QSPI_SET_FLASH_OFFSET_ADDR       = 78, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_79_QSPI_GET_FLASH_OFFSET_ADDR       = 79, /*   N      Y      N      Y      Y      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  /* fastboot */
  SYSCALL_80_FASTBOOT_GO_SET                  = 80, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_81_FASTBOOT_GO_GET                  = 81, /*   N      Y      N      Y      Y      Y   */
  /* aboot */
  SYSCALL_82_ABOOT_BOOT                       = 82, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_83_ABOOT_GO                         = 83, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_84_ABOOT_REGISTER_GO_CALLBACK       = 84, /*   N      Y      N      Y      Y      Y   */
  /* secureboot */
  SYSCALL_85_SB_VOLUME_INIT                   = 85, /*   N      Y      N      Y      Y      Y   */
  SYSCALL_86_SB_VOLUME_EXIT                   = 86, /*   N      Y      N      Y      Y      Y   */
  /* fastboot */
  SYSCALL_87_FASTBOOT_DISCONNECT_SET          = 87, /*   N      N      N      Y      Y      Y   */
  SYSCALL_88_FASTBOOT_DISCONNECT_GET          = 88, /*   N      N      N      Y      Y      Y   */
  SYSCALL_89_FASTBOOT_STATE_SET               = 89, /*   N      N      N      Y      Y      Y   */
  SYSCALL_90_FASTBOOT_STATE_GET               = 90, /*   N      N      N      Y      Y      Y   */
  SYSCALL_91_PRODUCTION_MODE_GET              = 91, /*   N      N      N      Y      Y      Y   */
  /* aboot */
  SYSCALL_92_ABOOT_REBOOT_DELAY_SET           = 92, /*   N      N      N      Y      Y      Y   */
  SYSCALL_93_ABOOT_REBOOT_DELAY_GET           = 93, /*   N      N      N      Y      Y      Y   */
  /* lzma */
  SYSCALL_94_LZMA_DECODE_INIT                 = 94, /*   N      N      N      Y      Y      Y   */
  SYSCALL_95_LZMA_DECODE_LOOP                 = 95, /*   N      N      N      Y      Y      Y   */
  SYSCALL_96_LZMA_DECODE_EXIT                 = 96, /*   N      N      N      Y      Y      Y   */
  /* secureboot */
  SYSCALL_97_SB_TLS_INIT                      = 97, /*   N      N      N      Y      Y      Y   */
  SYSCALL_98_SB_TLS_DEINIT                    = 98, /*   N      N      N      Y      Y      Y   */
  SYSCALL_99_SB_TLS_VERIFY_SIGNATURE          = 99, /*   N      N      N      Y      Y      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  SYSCALL_100_SB_TLS_VERIFY_HASH              = 100,/*   N      N      N      Y      Y      Y   */
  SYSCALL_101_SB_TLS_X509_CHECK_INTERGRITY    = 101,/*   N      N      N      Y      Y      Y   */
  SYSCALL_102_SB_TLS_X509_GET_AUTH_PARAM      = 102,/*   N      N      N      Y      Y      Y   */
  SYSCALL_103_PROCESS_POLL                    = 103,/*   N      N      N      N      Y      Y   */
  SYSCALL_104_PROCESS_POST_SYNCH              = 104,/*   N      N      N      N      Y      Y   */
  SYSCALL_105_SDHC_GET_ADMA2_DESC             = 105,/*   N      N      N      N      N      Y   */
/*----------------------------------------------------200730-220331-210531-211010---------------*/
/*-------------------------------------------------------------------------211016---------------*/
/*----------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------220808--------*/
/*--------------------------------------------------------------------------------221106--------*/
/*---------------------------------------------------------------------------------------220728-*/
/*---------------------------------------------------------------------------------------221111-*/
  SYSCALL_MAX                                 = 128,
} syscall_t;
/*---------------------------------------------------------------------------*/
void syscall_init(void);
int  syscall_register(syscall_t index, void *fn);
void syscall_unregister(syscall_t index);
void *syscall_get_handler(syscall_t index);
void **syscall_get_table(void);
/*---------------------------------------------------------------------------*/
#define AROM_VER_2020_07_30_CRANEGM_A0  20200730  /* CraneG/CraneM A0 */
#define AROM_VER_2021_05_31_JACANA_A0   20210531  /* Jacana A0 */
#define AROM_VER_2021_10_10_CRANEW_Z1   20211010  /* CraneW MCU Z1 */
#define AROM_VER_2021_10_16_CRANEL_A0   20211016  /* CraneL A0 */
#define AROM_VER_2022_03_31_SC2_A0      20220331  /* SC2 A0 */
#define AROM_VER_2022_07_28_CRANEW_Z2   20220728  /* CraneW MCU Z2 */
#define AROM_VER_2022_08_08_CRANEW_CR5  20220808  /* CraneW CR5 */
#define AROM_VER_2022_11_06_CRANEL_CR5  20221106  /* CraneLR A0 */
                                                  /* CraneLS A0 */
#define AROM_VER_2022_11_11_CRANEG_CR5  20221111  /* CraneGT Z1 */
/*---------------------------------------------------------------------------*/

#endif
