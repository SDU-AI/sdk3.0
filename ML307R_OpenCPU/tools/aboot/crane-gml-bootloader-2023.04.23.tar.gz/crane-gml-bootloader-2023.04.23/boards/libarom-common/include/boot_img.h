/* -*- C -*- */
/*
 * Copyright (c) 2020, ASR microelectronics
 * All rights reserved.
 */
#ifndef BOOT_IMG_H
#define BOOT_IMG_H

void slt_do_boot_prepare(void);

#endif /* BOOT_IMG_H */
