#ifndef _SDHC_SYSCALL_H_
#define _SDHC_SYSCALL_H_

void *sdhc_get_adma2_desc(void);

#endif
