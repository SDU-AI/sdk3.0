#ifndef __SYS_CLOSE_ALL_H
#define __SYS_CLOSE_ALL_H

void sys_close_all(void);

#endif /* __SYS_CLOSE_ALL_H */
