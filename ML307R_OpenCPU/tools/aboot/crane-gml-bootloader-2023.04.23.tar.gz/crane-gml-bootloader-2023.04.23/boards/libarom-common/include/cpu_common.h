#ifndef _CPU_COMMON_H_
#define _CPU_COMMON_H_

unsigned int hw_platform_type(void);

#endif /* _CPU_COMMON_H_ */
