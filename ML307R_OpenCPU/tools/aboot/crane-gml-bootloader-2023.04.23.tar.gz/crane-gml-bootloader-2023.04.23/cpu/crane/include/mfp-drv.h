#ifndef _MFP_DRV_H_
#define _MFP_DRV_H_

void spi_mfp_config(void);
void qspi_mfp_config(void);
void qspi_mfp_config_mx(void);

#endif
